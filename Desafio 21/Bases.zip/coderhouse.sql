-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-09-2021 a las 23:52:20
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `coderhouse`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carritos`
--

CREATE TABLE `carritos` (
  `id` int(10) UNSIGNED NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  `productos` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `carritos`
--

INSERT INTO `carritos` (`id`, `timestamp`, `productos`) VALUES
(2, '131231234', '[{\"title\":\"Pizarra\",\"price\":2600,\"thumbnail\":\"https://cdn3.iconfinder.com/data/icons/education-209/64/board-math-class-school-128.png\",\"timestamp\":1632081103866,\"descripcion\":\"Lorem ipsum\",\"codigo\":35,\"stock\":100},{\"title\":\"Calculadora\",\"price\":3450,\"thum');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id` int(11) NOT NULL,
  `value` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `dateStr` varchar(45) NOT NULL,
  `clientId` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id`, `value`, `email`, `dateStr`, `clientId`) VALUES
(0, '', '', '', ''),
(1, 'Hola', 'carlos@gmail.com', '09/26/2021 19:42:18', 'y8bQHNUQwKeL3fpPAAAN'),
(2, 'Como va?', 'juan@gmail.com', '09/26/2021 19:43:20', 'y8bQHNUQwKeL3fpPA2Ee');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `codigo` varchar(45) DEFAULT NULL,
  `stock` varchar(45) DEFAULT NULL,
  `timestamp` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `title`, `price`, `thumbnail`, `descripcion`, `codigo`, `stock`, `timestamp`) VALUES
(1, 'Gorro', 400.00, 'https://cdn3.iconfinder.com/data/icons/education-209/64/graduation-square-academic-cap-school-128.png', 'Lorem ipsum', '29', '100', '1632081103866'),
(2, 'Reloj', 830.00, 'https://cdn3.iconfinder.com/data/icons/education-209/64/clock-stopwatch-timer-time-128.png', 'Lorem ipsum', '30', '100', '1632081103866'),
(3, 'Calculadora', 350.00, 'https://cdn3.iconfinder.com/data/icons/education-209/64/calculator-math-tool-school-128.png', 'Lorem ipsum', '31', '100', '1632081103866'),
(4, 'Escuadra', 200.00, 'https://cdn3.iconfinder.com/data/icons/education-209/64/ruler-triangle-stationary-school-128.png', 'Lorem ipsum', '32', '100', '1632081103866'),
(5, 'Pizarra', 600.00, 'https://cdn3.iconfinder.com/data/icons/education-209/64/board-math-class-school-128.png', 'Lorem ipsum', '33', '100', '1632081103866'),
(6, 'Gorro', 400.00, 'https://cdn3.iconfinder.com/data/icons/education-209/64/graduation-square-academic-cap-school-128.png', 'Lorem ipsum', '34', '100', '1632081103866'),
(7, 'Pizarra', 2600.00, 'https://cdn3.iconfinder.com/data/icons/education-209/64/board-math-class-school-128.png', 'Lorem ipsum', '35', '100', '1632081103866');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prueba`
--

CREATE TABLE `prueba` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `categoria` varchar(45) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `prueba`
--

INSERT INTO `prueba` (`id`, `nombre`, `categoria`, `stock`) VALUES
(2, 'Leche', 'Lácteos', 45),
(3, 'Crema', 'Lácteos', 15);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carritos`
--
ALTER TABLE `carritos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `prueba`
--
ALTER TABLE `prueba`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carritos`
--
ALTER TABLE `carritos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `prueba`
--
ALTER TABLE `prueba`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
